/**
 * SPA functionality for admin panel
 */

// Handle navigation links
document.addEventListener('click', function (e) {
    // Check if clicked element is a link or inside a link
    const link = e.target.closest('a');
    
    if (!link) {
        return;
    }

    // Skip if:
    // - Link has download attribute
    // - Link has target="_blank"
    // - Link is for a different origin
    // - Link has data-method (for Laravel form spoofing)
    // - Link has data-ajax="false" (to opt-out)
    if (link.hasAttribute('download') ||
        link.target === '_blank' ||
        link.host !== window.location.host ||
        link.hasAttribute('data-method') ||
        link.getAttribute('data-ajax') === 'false') {
        return;
    }

    // Prevent default navigation
    e.preventDefault();

    // Get the URL
    const url = link.getAttribute('href');

    // Push state and load page
    window.history.pushState({ url }, '', url);
    loadPage(url);
});

// Handle form submissions via AJAX
document.addEventListener('submit', function (e) {
    const form = e.target.closest('form');
    
    if (!form) {
        return;
    }

    // Skip if form has data-ajax="false"
    if (form.getAttribute('data-ajax') === 'false') {
        return;
    }

    // Prevent default submission
    e.preventDefault();

    // Get form details
    const action = form.getAttribute('action') || window.location.pathname;
    const method = form.getAttribute('method') || 'GET';
    const formData = new FormData(form);

    // Submit via AJAX
    axios({
        url: action,
        method: method,
        data: formData,
        headers: {
            'Content-Type': 'multipart/form-data',
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => {
        // If the response is a redirect (status 3xx), follow it
        if (response.status >= 300 && response.status < 400) {
            const redirectUrl = response.headers.location;
            window.history.pushState({ url: redirectUrl }, '', redirectUrl);
            return loadPage(redirectUrl);
        }

        // If response data contains a redirect property (for JSON responses)
        if (response.data && response.data.redirect) {
            window.history.pushState({ url: response.data.redirect }, '', response.data.redirect);
            return loadPage(response.data.redirect);
        }

        // Otherwise, reload the current page
        loadPage(window.location.pathname + window.location.search);
    })
    .catch(error => {
        console.error('Form submission error:', error);
        // Show error message (you can implement a notification system)
        alert('An error occurred while submitting the form.');
    });
});

// Handle popstate (back/forward buttons)
window.addEventListener('popstate', function (e) {
    if (e.state && e.state.url) {
        loadPage(e.state.url);
    }
});

/**
 * Load a page via AJAX and update the content
 * @param {string} url - The URL to load
 */
function loadPage(url) {
    // Show loading indicator (optional)
    // You can add a loading spinner here

    // Fetch the page
    axios.get(url, {
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': 'text/html'
        }
    })
    .then(response => {
        // Handle redirect
        if (response.status >= 300 && response.status < 400) {
            const redirectUrl = response.headers.location;
            window.history.pushState({ url: redirectUrl }, '', redirectUrl);
            return loadPage(redirectUrl);
        }

        // Parse the HTML response
        const parser = new DOMParser();
        const doc = parser.parseFromString(response.data, 'text/html');

        // Extract title
        const titleElement = doc.querySelector('title');
        if (titleElement) {
            document.title = titleElement.textContent;
        }

        // Update actions section (if exists)
        const actionsElement = doc.querySelector('[data-actions]');
        const currentActions = document.querySelector('[data-actions]');
        if (actionsElement && currentActions) {
            currentActions.innerHTML = actionsElement.innerHTML;
        }

        // Update main content
        const contentElement = doc.querySelector('.admin-content');
        const currentContent = document.querySelector('.admin-content');
        if (contentElement && currentContent) {
            currentContent.innerHTML = contentElement.innerHTML;
        }

        // Update active state in sidebar
        updateActiveSidebar(url);

        // Re-initialize any JS components if needed
        // For example, if you have dropdowns, modals, etc., you may need to re-initialize them
        // We'll trigger a custom event that other scripts can listen for
        document.dispatchEvent(new CustomEvent('spa:load'));
    })
    .catch(error => {
        console.error('Page load error:', error);
        // Fallback to full page load
        window.location.href = url;
    });
}

/**
 * Update the active state in the sidebar based on the URL
 * @param {string} url - The current URL
 */
function updateActiveSidebar(url) {
    // Remove active class from all nav links
    document.querySelectorAll('.sidebar-nav .nav-link').forEach(link => {
        link.classList.remove('active');
    });

    // Find the link that matches the URL (or is a parent of the URL)
    const links = document.querySelectorAll('.sidebar-nav .nav-link');
    links.forEach(link => {
        const href = link.getAttribute('href');
        if (href && url.startsWith(href)) {
            link.classList.add('active');
        }
    });
}