<?php

use App\Http\Controllers\Api\CourseApiController;
use App\Http\Controllers\Api\FaqApiController;
use App\Http\Controllers\Api\GalleryApiController;
use App\Http\Controllers\Api\SettingApiController;
use App\Http\Controllers\Api\TestimonialApiController;
use App\Http\Controllers\Frontend\SpaController;
use Illuminate\Support\Facades\Route;

require __DIR__.'/admin.php';

// Public API endpoints
Route::get('/api/courses', [CourseApiController::class, 'index'])->name('api.courses.index');
Route::get('/api/courses/{slug}', [CourseApiController::class, 'show'])->name('api.courses.show');
Route::get('/api/testimonials', [TestimonialApiController::class, 'index'])->name('api.testimonials');
Route::get('/api/faqs', [FaqApiController::class, 'index'])->name('api.faqs');
Route::get('/api/gallery', [GalleryApiController::class, 'index'])->name('api.gallery');
Route::get('/api/settings', [SettingApiController::class, 'index'])->name('api.settings');
Route::post('/api/enquiries', [SpaController::class, 'submitEnquiry'])->name('api.enquiries');
Route::get('/api/csrf-token', function () {
    return response()->json(['token' => csrf_token()]);
})->name('api.csrf');

Route::get('/{any?}', [SpaController::class, 'index'])
    ->where('any', '.*')
    ->name('spa');
